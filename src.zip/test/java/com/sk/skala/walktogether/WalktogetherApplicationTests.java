package com.sk.skala.walktogether;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalktogetherApplicationTests {

    @Test
    void contextLoads() {
    }

}
