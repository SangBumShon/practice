package com.sk.skala.walktogether;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalktogetherApplication {

    public static void main(String[] args) {
        SpringApplication.run(WalktogetherApplication.class, args);
    }

}
